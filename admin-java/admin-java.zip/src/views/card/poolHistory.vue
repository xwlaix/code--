<template>
  <div class="app-container">
    1
  </div>
</template>

<script>
export default {
  name: '',
  data() {
    return {
    }
  },
  methods: {
  }
}
</script>
